 // example to test the TFT Display
// Thanks to the GraphicsDisplay and TextDisplay classes
// test2.bmp has to be on the mbed file system

//#define NO_DMA
#include "stdio.h"
#include "mbed.h"
#include "SPI_TFT_ILI9341.h"
#include "string"
#include "Arial12x12.h"
#include "Arial24x23.h"
#include "Arial28x28.h"
#include "font_big.h"
#include "SPI_STMPE610.h"
//############################################################################
char c,message[50],recived[100];bool sended=false;int _ligne=0;char type[28];
char ecrir(int posx,int posy);
void drawKeyboard(const char* _type);
void chat();
void drawButton(int x, int y);
int map(long x, long in_min, long in_max, long out_min, long out_max),s=0;
const char key[28]= {'A', 'Z', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P','Q', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L','M', 'W', 'X', 'C', 'V', 'B', 'N','\x27','<',};
const char key_c[28]= {'1', '2', '3', '4', '5', '6', '7', '8', '9', '0','(', ')', '-', '_', '@', '.', ':', ';', ',','<', '>', '!', '#', '=', '+', '*','?','<',};
//############################################################################
// the TFT is connected to SPI pin 11-14
SPI_STMPE610 TSC(D11, D12, D13, D3) ;
SPI_TFT_ILI9341 TFT(D11, D12, D13, D10,NC,D9,"TFT"); // mosi, miso, sclk, cs, reset, dc
Serial bluetooth(D8, D2);

int main()
{
     
     TFT.claim(stdout);      // send stdout to the TFT display
    TFT.background(Black);    // set background to black
    TFT.foreground(White);    // set chars to white
    TFT.cls();                // clear the screen
    TFT.set_font((unsigned char*) Arial12x12);
    TFT.set_orientation(1);

for(int i=0;i<28;i++)type[i]=key[i];
drawKeyboard(type);
chat();
}


void drawButton(int x, int y)
{
  TFT.fillrect(x-2, y-2, x+32, y+32, Red);// outter button color}
  TFT.fillrect(x, y, x+30, y+30, DarkGreen);// outter button color
}
void drawKeyboard(const char* _type){
    TFT.set_orientation(1);
    unsigned int i=2,j=124;unsigned int k=0;
   for(j;j<=218;j+=30) {
    for(i;i<=300;i+=30)
    {
        drawButton(i,j);
        TFT.locate(i+12,j+15);
        TFT._putc(_type[k]);
        k++;
    i+=2;
    }
    j+=2;i=15;
    if(j==158)i=30;
    }
    // draw spacebar
    TFT.fillrect(113,218,207, 242, Red);
  TFT.fillrect(115,220,205, 240, DarkGreen);
    TFT.locate(130,225);
    printf("SPACE");
      // sending bottun
    TFT.fillrect(250,90,320, 115, Red);
    TFT.locate(260,100);
    printf("Envoyer");
    // shift bottun
    TFT.fillrect(1,190,29, 220, Red);
  TFT.fillrect(2,188,27, 218, DarkGreen);
    TFT.locate(10,200);
    printf("^");
    }
    
    
void chat(){
 uint16_t touched, x, y, z ;
     while (true) {
         
         touched = TSC.getRAWPoint(&x, &y, &z) ;
     int xx=map(x,177,3850,0,240);
     int yy=map(y,220,3950,0,320);
          if (touched && x!=0 && y!=0) {
             ecrir(xx,yy);
                wait_ms(100);
       
                                         }

            if(sended){
                 TFT.locate(15,10);
                    TFT.set_orientation(1);
                    bluetooth.scanf("%[^\n]",recived);
                    TFT.foreground(Orange);
                    TFT.fillrect(0,0,300,80,Black);
                   TFT.printf("->%s\n",recived);//return;}
                   TFT.foreground(White);
                    sended=false;
                        }

                    }

}


int map(long x, long in_min, long in_max, long out_min, long out_max)
{
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

char ecrir(int posx,int posy)
{int i=0;TFT.set_orientation(0);
TFT.locate(5,100);
 if(posx<=118 && posx>=88)//LIGNE 1
 {
  for(int j=0;j<=9;j++) {
    if(posy>=i && posy<=i+30)
    {
     
       c=type[j];message[s++]=c;
       TFT.printf("-->%s",message);
      break;
    }
    i+=30;
    }
     }
if(posx>=58 && posx<=87)//LIGNE 2
 {
       i=15;
       for(int j=10;j<=18;j++) {
    if(posy>=i && posy<=i+30)
    {
       c=type[j];message[s++]=c;
      // TFT._putc(c);
       TFT.printf("-->%s",message);
      break;
    }
    i+=30;
    }
     }
if(posx>=28 && posx<=57)//LIGNE 3
 {
       i=30;
       for(int j=19;j<=26;j++) {
    if(posy>=i && posy<=i+30)
    {
       c=type[j];message[s++]=c;
       TFT.printf("-->%s",message);
      break;
    }
    i+=30;
    }
     
     }
    if(posx>=28 && posx<=57&& posy>=270 && posy<=300)//backspace
    {
        message[s-1]=' ';
        TFT.printf("-->%s",message);
         --s;
        }
    if(posx>=2 && posx<=20&& posy>=100 && posy<=200)//spacebar
    {
        c=' ';
        message[s++]=c;TFT.printf("-->%s",message);
         }
     if(posx>=120 && posx<=150 && posy>=140 && posy<=300)//envoyer
    {
         
         TFT.set_orientation(0);
         TFT.fillrect(120,0,145,250,Black);
        bluetooth.printf("%s\n",message);
         for(int i=0;i<50;i++)
        message[i]=NULL;
        c=NULL;
        s=0;
        sended=true;
  
     }
     if(posx>=28 && posx<=57&&posy>=0 && posy<=28)//shift
 {
       if(type[1]==key[1])
      for(int i=0;i<28;i++)
      {
          type[i]=key_c[i];
          }
        else
          for(int i=0;i<28;i++)
      {
          type[i]=key[i];
          }
    drawKeyboard(type);
     }
return c;
    }